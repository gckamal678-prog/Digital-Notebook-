# Backend prerequisites (not full HTML replacement)

Back up Realtime Database before deployment. Test rules with Firebase Emulator first.

## Deploy
Requires Node.js 20, Firebase CLI, and a Firebase plan/billing setup that supports scheduled Cloud Functions.
```sh
npm --prefix functions install
firebase login
firebase use digital-a2552
firebase deploy --only database,functions
```
Rules permit authenticated users to read/write only `users/{their UID}`. The scheduled function runs daily at 03:17 Asia/Kathmandu and removes only expired Trash copies with `deletedAt`/`expiresAt` in Unix milliseconds. It recognizes nested `trash/{category}/{id}` and flat `trash/{id}`.

Before production, confirm every page writes `deletedAt`, `expiresAt`, and its original record deletion atomically. This package does not complete HTML auth, old-data migration, page styling, or conflict-handling requirements.
