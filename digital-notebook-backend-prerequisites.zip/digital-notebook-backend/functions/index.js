"use strict";
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { initializeApp } = require("firebase-admin/app");
const { getDatabase } = require("firebase-admin/database");
const logger = require("firebase-functions/logger");
initializeApp();
const db = getDatabase();
const DAY30 = 30 * 24 * 60 * 60 * 1000;

exports.purgeExpiredTrash = onSchedule({schedule:"every day 03:17",timeZone:"Asia/Kathmandu",region:"asia-southeast1",retryCount:3}, async () => {
  const users = await db.ref("users").get();
  const now = Date.now(), jobs = [];
  users.forEach(user => {
    const trash = user.child("trash");
    trash.forEach(first => {
      const v = first.val();
      const nested = v && typeof v === "object" && !Array.isArray(v) && !("deletedAt" in v) && !("originalPath" in v) && !("recordType" in v);
      if (nested) first.forEach(rec => jobs.push(purgeOne(user.key, `trash/${first.key}/${rec.key}`, rec.val(), now)));
      else jobs.push(purgeOne(user.key, `trash/${first.key}`, v, now));
    });
  });
  const result = await Promise.allSettled(jobs);
  const count = result.filter(x => x.status === "fulfilled" && x.value).length;
  result.filter(x => x.status === "rejected").forEach(x => logger.error("Trash cleanup failed", x.reason));
  logger.info(`Expired trash entries removed: ${count}`);
});
async function purgeOne(uid, path, entry, now) {
  if (!entry || typeof entry !== "object") return false;
  const deletedAt = Number(entry.deletedAt || 0);
  const expiresAt = Number(entry.expiresAt || (deletedAt ? deletedAt + DAY30 : 0));
  if (!deletedAt || expiresAt > now) return false;
  const ref = db.ref(`users/${uid}/${path}`);
  const snap = await ref.get();
  if (!snap.exists()) return false;
  const current = snap.val(), d = Number(current.deletedAt || 0);
  const e = Number(current.expiresAt || (d ? d + DAY30 : 0));
  if (d !== deletedAt || e > now) return false;
  await ref.remove();
  return true;
}
